package com.androidpprog2.proyectolasalle.fragments.login;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.helpers.User_helper;


public class register_fragment extends Fragment implements User_helper.user_listener {


    private User user = new User();

    private Button mRegisterButton;
    private Button mBackButton;

    private EditText user_name;
    private EditText user_last_name;
    private EditText user_email;
    private EditText user_password;
    private EditText user_image;

    private Context context;

    public register_fragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_register, container, false);

        //FIND VIEWS
        mRegisterButton = v.findViewById(R.id.register_button);
        mBackButton = v.findViewById(R.id.back_register_button);
        user_name = v.findViewById(R.id.name_textbox);
        user_last_name = v.findViewById(R.id.last_name_textbox);
        user_email = v.findViewById(R.id.email_textbox);
        user_password = v.findViewById(R.id.password_textbox);
        user_image = v.findViewById(R.id.user_image);

        //REGISTER BUTTON CLICK
        mRegisterButton.setOnClickListener(view ->{
            user.name = user_name.getText().toString();
            user.last_name = user_last_name.getText().toString();
            user.email = user_email.getText().toString();
            user.password = user_password.getText().toString();
            user.image = user_image.getText().toString();


            User_helper.register(user, register_fragment.this,context);
        } );

        //BACK BUTTON CLICK
        mBackButton.setOnClickListener(view -> NavHostFragment.findNavController(register_fragment.this).navigate(R.id.action_register_fragment_to_home_fragment));

        return v;
    }

    @Override
    public void on_user_receive(User u) {
        System.out.println(u.name);
    }
}