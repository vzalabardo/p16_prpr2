package com.androidpprog2.proyectolasalle.entities;

public class Message {
    public String content;
    public int user_id_send;
    public int user_id_received;

}
