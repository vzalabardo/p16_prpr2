package com.androidpprog2.proyectolasalle.entities.events;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;

public class EventHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public Generic_helper.OnListItemClick onListItemClick;

    public int event_id;
    public ImageView event_image;
    public TextView event_name;
    public TextView event_location;
    public TextView event_date;


    public EventHolder(View v, Generic_helper.OnListItemClick onListItemClick) {
        super(v);
        //v.setOnClickListener(this);
        this.onListItemClick = onListItemClick;
        itemView.setOnClickListener(this);
        event_image = itemView.findViewById(R.id.event_image);
        event_name = itemView.findViewById(R.id.event_name);
        event_location = itemView.findViewById(R.id.event_location);
        event_date = itemView.findViewById(R.id.event_date);


    }

    @Override
    public void onClick(View view) {
        onListItemClick.onClick(view,this.event_id);
    }
}
