package com.androidpprog2.proyectolasalle.fragments.friends;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event_adapter;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.events.main_logged_fragment;
import com.androidpprog2.proyectolasalle.fragments.users.users_fragment;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.google.gson.Gson;

import java.util.List;


public class friends_fragment extends Fragment implements User_helper.user_listener, User_helper.friends_listener {

    RecyclerView friends_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;

    public friends_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_friends, container, false);

        friends_rec_views = v.findViewById(R.id.friends_recycler_view);
        friends_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        User_helper.get_user_friends(friends_fragment.this,context);

        return v;
    }

    @Override
    public void on_user_receive(User u) {
        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("user",g.toJson(u));
        NavHostFragment.findNavController(friends_fragment.this).navigate(R.id.action_friends_fragment_to_show_profile_fragment,bundle);
    }


    @Override
    public void on_friends_receive(List<User> u_list) {
        adapter = new User_adapter(u_list, friends_fragment.this);
        friends_rec_views.setAdapter(adapter);
    }
}