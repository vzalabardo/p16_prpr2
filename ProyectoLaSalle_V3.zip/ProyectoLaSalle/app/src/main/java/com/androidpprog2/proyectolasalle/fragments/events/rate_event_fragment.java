package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.Assistance;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.messages.Message;
import com.androidpprog2.proyectolasalle.fragments.messages.write_message_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;


public class rate_event_fragment extends Fragment implements Event_helper.event_assistance_listener {
    Event event = new Event();
    private EditText user_comment;
    private android.widget.RatingBar rateBar;
    private Button rateButton;
    private Context context;




    public rate_event_fragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_rate_event, container, false);

        //GET EVENT ID
        if (getArguments() != null){
            event.id = getArguments().getInt("id");
        }

        user_comment = v.findViewById(R.id.user_comment);
        rateBar = v.findViewById(R.id.ratingBar);
        rateButton = v.findViewById(R.id.rate_Button);

        rateButton.setOnClickListener(view -> {
            Assistance assistance = new Assistance();
            assistance.event_id = event.id;
            assistance.user_id = manager.get_manager().user.id;
            assistance.comentary = user_comment.getText().toString();
            assistance.puntuation = rateBar.getNumStars();

            Event_helper.rate_assistance(rate_event_fragment.this,context,v,assistance,String.valueOf(assistance.user_id),String.valueOf(assistance.event_id));

        });

        return v;
    }

    @Override
    public void on_event_assistances_post(View v) {
        Snackbar.make(v, "Event Rated!", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }
}