package com.androidpprog2.proyectolasalle.entities.events;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;


import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Event_adapter extends RecyclerView.Adapter<EventHolder> {

    public List<Event> e_list;
    private Event_helper.event_listener onListItemClick;


    public Event_adapter(List<Event> e_list, Event_helper.event_listener onListItemClick){
        this.e_list = e_list;
        this.onListItemClick = onListItemClick;
    }

    public EventHolder onCreateViewHolder(ViewGroup container, int viewType){
        View v = LayoutInflater.from(container.getContext()).inflate(R.layout.event_item, container, false);
        return new EventHolder(v,onListItemClick);
    }

    @Override
    public void onBindViewHolder(EventHolder holder, int position) {
        holder.fill_holder_fields(e_list.get(position));
    }

    @Override
    public int getItemCount() {
        return e_list.size();
    }

}
