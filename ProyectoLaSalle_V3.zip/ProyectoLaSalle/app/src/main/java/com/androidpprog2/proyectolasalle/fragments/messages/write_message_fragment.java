package com.androidpprog2.proyectolasalle.fragments.messages;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.messages.Message;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;


public class write_message_fragment extends Fragment implements Message_helper.message_send_listener {

    private User user = new User();
    private TextView user_dest;
    private ImageView user_image;
    private EditText user_message;
    private Button sendMessageButton;
    private Context context;

    public write_message_fragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_write_message, container, false);

        //DATA FROM TARGET USER
        if (getArguments() != null){
            user.id = getArguments().getInt("id");
            user.name = getArguments().getString("name");
            user.last_name = getArguments().getString("last_name");
            user.image = getArguments().getString("image");
        }


        //FIND VIEWS
        user_dest = v.findViewById(R.id.user_dest);
        user_image = v.findViewById(R.id.user_image);
        user_message = v.findViewById(R.id.user_message);
        sendMessageButton = v.findViewById(R.id.sendMessage_Button);

        user_dest.setText(user.name + " " + user.last_name);
        try{ Picasso.get().load(user.image).into(user_image);}
        catch (Exception e) { e.printStackTrace();}

        //SEND MESSAGE CLICK
        sendMessageButton.setOnClickListener(view -> {
            Message message = new Message();

            message.content = user_message.getText().toString();
            message.user_id_send = manager.get_manager().user.id;
            message.user_id_recived = user.id;

            Message_helper.post_message(message,write_message_fragment.this,context,v);


        });

        return v;
    }

    @Override
    public void on_message_send(View v) {
        Snackbar.make(v, "Message Sent", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    @Override
    public void on_message_error(View v) {
        Snackbar.make(v, "Message Error", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }
}