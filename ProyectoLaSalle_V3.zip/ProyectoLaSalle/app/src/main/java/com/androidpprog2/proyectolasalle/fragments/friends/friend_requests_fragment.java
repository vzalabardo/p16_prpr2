package com.androidpprog2.proyectolasalle.fragments.friends;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.friends.FriendAdapter;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.users.users_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;


public class friend_requests_fragment extends Fragment implements User_helper.users_listener, User_helper.user_request_receive, User_helper.user_accept_request_listener, User_helper.user_delete_listener {
    RecyclerView users_rec_views;
    RecyclerView.Adapter adapter;

    private Context context    ;

    public friend_requests_fragment() {
        // Required empty public constructor
    }


    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_friend_requests, container, false);
        users_rec_views = v.findViewById(R.id.users_recycler_view);
        users_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        User_helper.get_user_friend_requests(friend_requests_fragment.this,context);

        return v;
    }

    @Override
    public void on_users_receive(List<User> u_list) {
        adapter = new FriendAdapter(u_list, friend_requests_fragment.this,friend_requests_fragment.this);
        users_rec_views.setAdapter(adapter);
    }


    @Override
    public void on_user_accept_receive(User u) {
        User_helper.accept_friend_request(friend_requests_fragment.this,context,String.valueOf(u.id));
    }

    @Override
    public void on_user_decline_receive(User u) {
        User_helper.delete_friend(friend_requests_fragment.this,context,String.valueOf(u.id));
    }

    @Override
    public void on_user_request_accept() {

        User_helper.get_user_friend_requests(friend_requests_fragment.this,context);

        Snackbar.make(this.getView(), "Friend Request Accepted", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void on_user_delete() {
        User_helper.get_user_friend_requests(friend_requests_fragment.this,context);

        Snackbar.make(this.getView(), "Friend Request Declined", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        adapter.notifyDataSetChanged();
    }
}