package com.androidpprog2.proyectolasalle.helpers;

import android.view.View;

public class Generic_helper {
    public interface OnListItemClick {
        void onClick(int id);
    }
}
