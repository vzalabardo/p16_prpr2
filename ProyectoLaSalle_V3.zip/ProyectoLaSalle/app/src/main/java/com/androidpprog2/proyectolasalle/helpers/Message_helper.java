package com.androidpprog2.proyectolasalle.helpers;

import android.content.Context;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.androidpprog2.proyectolasalle.entities.messages.Message;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.manager;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Message_helper {
    public interface message_send_listener{
        void on_message_send(View view);
        void on_message_error(View view);}

    public interface message_conversations_listener{
        void on_message_conversations_receive(List<User> u_list);}

    public interface messages_receive_listener{
        void on_messages_receive_listener(List<Message> m_list);}

    public interface message_receive_listener{
        void on_message_receive_listener(Message e);}

    static public void post_message(Message m, Message_helper.message_send_listener m_listener, Context context, View v){
        String url = manager.get_manager().url_api + "messages";
        RequestQueue queue = Volley.newRequestQueue(context);

        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("content",m.content);
            JSON_user.put("user_id_send",m.user_id_send);
            JSON_user.put("user_id_recived",m.user_id_recived);}
        catch (JSONException e) {
            e.printStackTrace();}

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, JSON_user,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("respuesta", "Sending Message correct:" + response);
                        m_listener.on_message_send(v);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("resposta", "Sending Message error:" + error);
                m_listener.on_message_error(v);
            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonObjReq);
    }

    static public void get_conversations(Message_helper.message_conversations_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "messages/users";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA EVENTOS: "+ response.toString());

                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        u_listener.on_message_conversations_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA ERROR EVENTOS:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    static public void get_messages_by_user_id(Message_helper.messages_receive_listener messages_receive_listener, Context context, String id){
        String url = manager.get_manager().url_api + "messages/" + id;
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "Respuesta Mensajes Conversacion: "+ response.toString());

                        Gson g = new Gson();
                        List<Message> m_list = Arrays.asList(g.fromJson(response.toString(), (Type) Message[].class));
                        messages_receive_listener.on_messages_receive_listener(m_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Respuesta Mensajes Conversacion Error:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }
}
