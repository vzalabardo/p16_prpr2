package com.androidpprog2.proyectolasalle.fragments.users;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.Statistic;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.events.Event_adapter;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.events.event_details_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.util.List;


public class show_profile_fragment extends Fragment implements User_helper.user_assistances_listener, Event_helper.event_listener, User_helper.user_send_request_listener, User_helper.user_delete_listener, User_helper.user_statistic_receive {
    RecyclerView events_user_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;
    private User user = new User();

    private TextView user_full_name;
    private ImageView user_image;
    private TextView user_email;
    private TextView user_score;
    private TextView user_num_comments;
    private TextView user_comments_below;

    private Button editProfileButton;
    private Button newMessageButton;
    private Button sendFriendRequestButton;


    public show_profile_fragment() {
        // Required empty public constructor
    }
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_show_profile, container, false);
        if (getArguments() != null){
            Gson g = new Gson();
            user = g.fromJson(getArguments().getString("user"),User.class);

            System.out.println(user.name);
        }
        if(user.id == 0){
            user = manager.get_manager().user;
        }
        //GET CURRENT USER
        //User_helper.get_user_by_value(show_profile_fragment.this, context, String.valueOf(user.id));

        User_helper.get_user_assistances(show_profile_fragment.this,context,String.valueOf(user.id));
        User_helper.get_user_statistics(show_profile_fragment.this,context,String.valueOf(user.id));

        //FIND VIEWS
        events_user_rec_views = v.findViewById(R.id.events_user_recycler_view);
        events_user_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        user_full_name = v.findViewById(R.id.user_full_name);
        user_image = v.findViewById(R.id.user_image);
        user_email = v.findViewById(R.id.user_email);
        user_score = v.findViewById(R.id.user_avg_score);
        user_num_comments = v.findViewById(R.id.user_num_comments);
        user_comments_below = v.findViewById(R.id.user_comments_below);
        editProfileButton = v.findViewById(R.id.editProfileButton);
        newMessageButton = v.findViewById(R.id.newMessage_Button);
        sendFriendRequestButton = v.findViewById(R.id.sendFriendRequest_button);

        //FILL EVENT TEXT FIELDS
        user_full_name.setText(user.name + " " + user.last_name);
        try{Picasso.get().load(user.image).into(user_image);}
        catch (Exception e) { e.printStackTrace(); }
        user_email.setText(user.email);



        //editProfileButton
        //click


        editProfileButton.setOnClickListener(view -> NavHostFragment.findNavController(show_profile_fragment.this).navigate(R.id.action_show_profile_fragment_to_edit_profile_fragment));
        newMessageButton.setOnClickListener(view ->{
                Bundle bundle = new Bundle();
                bundle.putInt("id",user.id);
                bundle.putString("name",user.name);
                bundle.putString("last_name",user.last_name);
                bundle.putString("image",user.image);
                NavHostFragment.findNavController(show_profile_fragment.this).navigate(R.id.action_show_profile_fragment_to_write_message_fragment,bundle);
        });
        //Invisible/visible
        if(user.id != manager.get_manager().user.id){ editProfileButton.setVisibility(View.GONE); }
        else{
            newMessageButton.setVisibility(View.GONE);
            sendFriendRequestButton.setVisibility(View.GONE);
        }

        sendFriendRequestButton.setOnClickListener(view -> {
            User_helper.send_friend_request(show_profile_fragment.this,context,v,String.valueOf(user.id));
        });

        for(User friend : manager.get_manager().friends_list){
            if(friend.id == user.id){
                sendFriendRequestButton.setVisibility(View.GONE);
            }
        }

        return v;
    }



    @Override
    public void on_user_assistances_receive(List<Event> e_list) {
        adapter = new Event_adapter(e_list, show_profile_fragment.this);
        events_user_rec_views.setAdapter(adapter);
    }

    @Override
    public void on_event_receive(Event e) {
        Gson g = new Gson();

        Bundle bundle = new Bundle();
        bundle.putString("event",g.toJson(e));
        NavHostFragment.findNavController(show_profile_fragment.this).navigate(R.id.action_show_profile_fragment_to_event_details_fragment,bundle);
    }

    @Override
    public void on_user_request_post(View v) {
        Snackbar.make(v, "Friend Request sent", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    @Override
    public void on_user_delete() {
        Snackbar.make(this.getView(), "Friend Deleted", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    @Override
    public void on_user_statistic_receive(Statistic s) {
        user_score.setText("Score: " + s.avg_score);
        user_num_comments.setText("Comments: " + s.num_comments);
        user_comments_below.setText("%Comments below: " + s.percentage_commenters_below);
    }
}