package com.androidpprog2.proyectolasalle.entities.friends;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;

public class FriendHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public User_helper.user_request_receive onAcceptClick;
    public User_helper.user_request_receive onDeclineClick;

    public User user = new User();
    public ImageView user_image;
    public TextView user_full_name;
    public Button acceptButton;
    public Button declineButton;


    public FriendHolder(View v, User_helper.user_request_receive onAcceptClick, User_helper.user_request_receive onDeclineClick) {
        super(v);
        this.onAcceptClick = onAcceptClick;
        this.onDeclineClick = onDeclineClick;
        itemView.setOnClickListener(this);
        user_full_name = itemView.findViewById(R.id.user_full_name);
        user_image = itemView.findViewById(R.id.user_image);
        acceptButton = itemView.findViewById(R.id.acceptButton);
        declineButton = itemView.findViewById(R.id.declineButton);


        acceptButton.setOnClickListener(view -> {
            onAcceptClick.on_user_accept_receive(user);
        });
        declineButton.setOnClickListener(view -> {
            onDeclineClick.on_user_decline_receive(user);
        });

    }


    public void fill_holder_fields(User u){
        user = u;
        user_full_name.setText(user.name + " " + user.last_name);
        try { Picasso.get().load(user.image).into(user_image); }
        catch(Exception e) { System.out.println(e); }
    }

    @Override
    public void onClick(View view) {

    }


}
