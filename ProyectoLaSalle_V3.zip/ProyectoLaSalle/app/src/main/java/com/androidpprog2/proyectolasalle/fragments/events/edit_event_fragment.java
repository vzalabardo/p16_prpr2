package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;

public class edit_event_fragment extends Fragment {

    private Event event = new Event();
    private EditText event_name;
    private EditText event_image;
    private EditText event_location;
    private EditText event_description;
    private EditText event_startDate;
    private EditText event_endDate;
    private EditText event_maxParticipators;
    private EditText event_type;

    private Button editEventButton;
    private Button backButton;
    private Context context;

    public edit_event_fragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_edit_event, container, false);

        //FIND VIEWS
        event_name = v.findViewById(R.id.event_name_textbox);
        event_image = v.findViewById(R.id.event_image_textbox);
        event_location = v.findViewById(R.id.event_location_textbox);
        event_description = v.findViewById(R.id.event_description_textbox);
        event_startDate = v.findViewById(R.id.event_startDate_textbox);
        event_endDate = v.findViewById(R.id.event_endDate_textbox);
        event_maxParticipators = v.findViewById(R.id.event_maxParticipators_textbox);
        event_type = v.findViewById(R.id.event_type_textbox);

        editEventButton = v.findViewById(R.id.editEvent_button);
        backButton = v.findViewById(R.id.back_postEvent_button);

        return v;
    }
}