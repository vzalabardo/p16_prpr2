package com.androidpprog2.proyectolasalle.fragments.users;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.squareup.picasso.Picasso;


public class show_profile_fragment extends Fragment implements User_helper.user_listener {

    private TextView user_full_name;
    private ImageView user_image;
    private TextView user_email;
    private TextView user_score;
    private TextView user_num_comments;
    private TextView user_comments_below;

    private Button editProfileButton;
    private Context context;


    public show_profile_fragment() {
        // Required empty public constructor
    }
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_show_profile, container, false);

        //GET CURRENT USER
        User_helper.get_user_by_value(show_profile_fragment.this, context, manager.get_manager().user.email);

        //FIND VIEWS
        user_full_name = v.findViewById(R.id.user_full_name);
        user_image = v.findViewById(R.id.user_image);
        user_email = v.findViewById(R.id.user_email);
        user_score = v.findViewById(R.id.user_avg_score);
        user_num_comments = v.findViewById(R.id.user_num_comments);
        user_comments_below = v.findViewById(R.id.user_comments_below);
        editProfileButton = v.findViewById(R.id.editProfileButton);



        //editProfileButton
        editProfileButton.setOnClickListener(view -> NavHostFragment.findNavController(show_profile_fragment.this).navigate(R.id.action_show_profile_fragment_to_edit_profile_fragment));

        return v;
    }

    @Override
    public void on_user_receive(User u) {
        //FILL MANAGER USER
        manager.get_manager().user.name = u.name;
        manager.get_manager().user.last_name = u.last_name;
        manager.get_manager().user.image = u.image;
        //FILL TEXT FIELDS
            user_full_name.setText(u.name + " " + u.last_name);
            try{
                Picasso.get().load(u.image).into(user_image);}
             catch (Exception e) {
                 e.printStackTrace();
             }
            user_email.setText(u.email);
            user_score.setText("AVG SCORE: " + u.statistics.avg_score.toString());
            user_num_comments.setText("NUM COMMENTS: " + u.statistics.num_comments);
            user_comments_below.setText("PERCENTAGE COMMENTS BELOW: " + u.statistics.percentage_commenters_below.toString());
    }
}