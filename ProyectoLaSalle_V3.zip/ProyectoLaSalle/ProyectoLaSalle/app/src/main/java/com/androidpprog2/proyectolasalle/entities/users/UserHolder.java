package com.androidpprog2.proyectolasalle.entities.users;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;

public class UserHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public User u;
    public ImageView user_image;
    public TextView user_full_name;
    public TextView user_email;

    public UserHolder(LayoutInflater inflater, ViewGroup container, Context context){
        super(inflater.inflate(R.layout.user_item, container, false));
        itemView.setOnClickListener(this);
        user_image = itemView.findViewById(R.id.user_image);
        user_full_name = itemView.findViewById(R.id.user_full_name);
        user_email = itemView.findViewById(R.id.user_email);
    }

    @Override
    public void onClick(View view) {
        //TODO EventHolder on click User Details

        //NavHostFragment.findNavController(main).navigate(R.id.action_main_logged_fragment_to_users_fragment);
    }
}
