package com.androidpprog2.proyectolasalle.entities.users;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;


import com.squareup.picasso.Picasso;

import java.util.List;

public class User_adapter extends RecyclerView.Adapter<UserHolder> {
    private List<User> u_list;
    private Context context;

    public User_adapter(List<User> u_list) { this.u_list = u_list; }

    @Override
    public UserHolder onCreateViewHolder(ViewGroup container, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(container.getContext());
        return new UserHolder(layoutInflater,container,container.getContext());
    }

    @Override
    public void onBindViewHolder(UserHolder holder, int position) {
        holder.user_full_name.setText(u_list.get(position).name + " " + u_list.get(position).last_name);
        holder.user_email.setText(u_list.get(position).email);

        try { Picasso.get().load(u_list.get(position).image).into(holder.user_image); }
        catch(Exception e) { System.out.println(e.toString()); }


    }

    @Override
    public int getItemCount() {
        return u_list.size();
    }
}
