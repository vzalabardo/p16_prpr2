package com.androidpprog2.proyectolasalle.fragments.login;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;

public class login_fragment extends Fragment implements User_helper.user_listener{

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    private User user = new User();

    private Button mLoginButton;
    private Button mBackButton;

    private EditText user_email;
    private EditText user_password;

    private Context context;

    public login_fragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_login, container, false);

        //FIND VIEWS
        mLoginButton = v.findViewById(R.id.login_button);
        mBackButton = v.findViewById(R.id.back_login_button);
        user_email = v.findViewById(R.id.email_textbox);
        user_password = v.findViewById(R.id.password_textbox);

        //LOGIN BUTTON CLICK
        mLoginButton.setOnClickListener(view -> {
            user.email = user_email.getText().toString();
            user.password = user_password.getText().toString();

            User_helper.login(user,login_fragment.this,context);
        });

        //BACK BUTTON CLICK
        mBackButton.setOnClickListener(view -> NavHostFragment.findNavController(login_fragment.this).navigate(R.id.action_login_fragment_to_home_fragment));
        return v;
    }

    @Override
    public void on_user_receive(User u) {
        System.out.println(manager.get_manager().user.accesToken);
        if(manager.get_manager().user.accesToken != ""){
            NavHostFragment.findNavController(login_fragment.this).navigate(R.id.action_login_fragment_to_main_logged_fragment);
            System.out.println("LOGIN");
        }
        else{
            System.out.println("LOGIN ERROR");
        }
    }
}