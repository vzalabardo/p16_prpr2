package com.androidpprog2.proyectolasalle.helpers;

import android.content.Context;

import com.android.volley.toolbox.Volley;
import com.androidpprog2.proyectolasalle.entities.Message;
import com.androidpprog2.proyectolasalle.manager;

public class Message_helper {
    public interface message_listener{
        void on_message_receive(Message m);}

    static public void post_event(Message m, Message_helper.message_listener m_listener, Context context){
        String url = manager.get_manager().url_api + "messages";
        m_listener.on_message_receive(m);
        Volley.newRequestQueue(context);}

}
