package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.events.Event_adapter;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.fragments.login.login_fragment;
import com.androidpprog2.proyectolasalle.fragments.users.users_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class main_logged_fragment extends Fragment implements Event_helper.events_listener,Event_helper.event_listener, User_helper.user_listener,User_helper.users_listener, User_helper.friends_listener {

    private Switch best_switch;
    private TextInputLayout event_searcher;
    private TextInputLayout event_location_searcher;

    private String event_k_string;
    private String event_l_string;

    private CountDownTimer countDownTimer = null;
    private List<Event> e_list = new ArrayList<Event>();


    RecyclerView events_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;

    private FloatingActionButton addEventButton;


    public main_logged_fragment() {
        // Required empty public constructor
    }
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main_logged_fragment, container, false);

        //LOAD API EVENTOS
        Event_helper.get_events(main_logged_fragment.this,context);
        ///LOAD API CURRENT USUARIO
        User_helper.get_user_by_value(main_logged_fragment.this, context, manager.get_manager().user.email);
        //LOAD API USUARIOS
        User_helper.get_users(main_logged_fragment.this,context);
        //LOAD API FRIENDS
        User_helper.get_user_friends(main_logged_fragment.this,context);

        //FIND VIEWS
        events_rec_views = v.findViewById(R.id.events_recycler_view);
        events_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));
        addEventButton = v.findViewById(R.id.add_event_button);
        event_searcher = v.findViewById(R.id.event_searcher);
        event_location_searcher = v.findViewById(R.id.event_location_searcher);
        best_switch = v.findViewById(R.id.switch_best);

        //event_searcher
        event_searcher.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                System.out.println(charSequence.toString());
                if(countDownTimer != null){
                    countDownTimer.cancel();
                }
                countDownTimer = new CountDownTimer(750,750) {
                    @Override
                    public void onTick(long l) {

                    }
                    @Override
                    public void onFinish() {
                        System.out.println("Finish timer");
                        event_k_string = charSequence.toString();
                        Event_helper.get_events_by_value(main_logged_fragment.this,context,event_k_string,event_l_string,"","");
                    }
                };
                countDownTimer.start();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //System.out.println(editable.toString());

            }
        });

        //event_searcher
        event_location_searcher.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                System.out.println(charSequence.toString());
                if(countDownTimer != null){
                    countDownTimer.cancel();
                }
                countDownTimer = new CountDownTimer(750,750) {
                    @Override
                    public void onTick(long l) {

                    }
                    @Override
                    public void onFinish() {
                        System.out.println("Finish timer");
                        event_l_string = charSequence.toString();
                        Event_helper.get_events_by_value(main_logged_fragment.this,context,event_k_string,event_l_string,"","");
                    }
                };
                countDownTimer.start();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //System.out.println(editable.toString());

            }
        });

        //addEventButton
        addEventButton.setOnClickListener(view -> NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_add_event_fragment));

        best_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(best_switch.isChecked()){
                    Event_helper.get_best_events(main_logged_fragment.this,context);
                }
                else{
                    Event_helper.get_events(main_logged_fragment.this,context);
                }
            }
        });

        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(),  new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                System.out.println("Click on Log Out to return");
            }
        });


        return v;
    }




    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile_menuButton:  {
                System.out.print("Profile Menu ButtonCLICADO");
                Gson g = new Gson();

                Bundle bundle = new Bundle();
                bundle.putString("user",g.toJson(manager.get_manager().user));
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_show_profile_fragment,bundle);
                return true;
            }
            case R.id.users_menuButton:  {
                System.out.print("Users Menu Button CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_users_fragment);
                return true;
            }
            case R.id.messages_menuButton:  {
                System.out.print("Messages Menu Button CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_messages_fragment);
                return true;
            }
            case R.id.friends_menuButton:  {
                System.out.print("Friends Menu Button CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_friends_fragment);
                return true;
            }
            case R.id.friend_requests_menuButton:  {
                System.out.print("Friend Requests Menu Button CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_friend_requests_fragment);
                return true;
            }
            case R.id.logout_menuButton:  {
                System.out.print("Log Out Menu Button CLICADO");
                manager.get_manager().user = new User();
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_home_fragment);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }

    }



    @Override
    public void on_events_receive(List<Event> event_list){
        e_list.clear();
        e_list.addAll(event_list);

        //RECYCLE VIEW
        if(manager.get_manager().e_list.size() == 0){
            manager.get_manager().e_list = event_list;
        }

        if (adapter == null){
            adapter = new Event_adapter(e_list,main_logged_fragment.this);
        }
        if(events_rec_views.getAdapter() == null){
            events_rec_views.setAdapter(adapter);
        }
        adapter.notifyDataSetChanged();

    }

    @Override
    public void on_user_receive(User u) {
        manager.get_manager().user.id = u.id;
        manager.get_manager().user.name = u.name;
        manager.get_manager().user.last_name = u.last_name;
        manager.get_manager().user.email = u.email;
        manager.get_manager().user.password = u.password;
        manager.get_manager().user.image = u.image;
    }

    @Override
    public void on_users_receive(List<User> u_list) {

        manager.get_manager().u_list = u_list;
    }

    @Override
    public void on_event_receive(Event e) {
        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("event",g.toJson(e));
        NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_event_details_fragment,bundle);
    }

    @Override
    public void on_friends_receive(List<User> u_list) {
        manager.get_manager().friends_list = u_list;
    }
}