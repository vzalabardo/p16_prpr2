package com.androidpprog2.proyectolasalle.entities.events;

public class Event {
    public int id;
    public String name;
    public String image;
    public String location;
    public String description;
    public String eventStart_date;
    public String eventEnd_date;
    public int n_participators;
    public String type;
    public int owner_id;
    public String date;


}
