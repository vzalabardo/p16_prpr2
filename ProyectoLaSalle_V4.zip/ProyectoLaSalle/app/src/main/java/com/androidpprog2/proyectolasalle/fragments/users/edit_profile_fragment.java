package com.androidpprog2.proyectolasalle.fragments.users;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.fragments.events.event_details_fragment;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;


public class edit_profile_fragment extends Fragment implements User_helper.user_listener {

    private User user = new User();

    private EditText name_textbox;
    private EditText last_name_textbox;
    private EditText email_textbox;
    private EditText password_textbox;
    private EditText image_textbox;
    private Button confirmButton;
    private Button backButton;
    private Context context;

    public edit_profile_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_edit_profile, container, false);

        getActivity().invalidateOptionsMenu();
        setHasOptionsMenu(true);

        //FIND VIEWS
        name_textbox = v.findViewById(R.id.name_textbox);
        last_name_textbox = v.findViewById(R.id.last_name_textbox);
        email_textbox = v.findViewById(R.id.email_textbox);
        password_textbox = v.findViewById(R.id.password_textbox);
        image_textbox = v.findViewById(R.id.image_textbox);

        confirmButton = v.findViewById(R.id.confirm_button);
        backButton = v.findViewById(R.id.back_editProfile_button);

        //FILL EDIT TEXT FIELDS
        User u = manager.get_manager().user;
        name_textbox.setText(u.name);
        last_name_textbox.setText(u.last_name);
        email_textbox.setText(u.email);
        image_textbox.setText(u.image);

        //confirmButton
        confirmButton.setOnClickListener(view ->{
            user.name = name_textbox.getText().toString();
            user.last_name = last_name_textbox.getText().toString();
            user.email = email_textbox.getText().toString();
            user.password = password_textbox.getText().toString();
            user.image = image_textbox.getText().toString();

            User_helper.edit_profile(user, edit_profile_fragment.this,context);
        });

        //backButton
        backButton.setOnClickListener(view -> NavHostFragment.findNavController(edit_profile_fragment.this).navigate(R.id.action_edit_profile_fragment_to_show_profile_fragment));

        return v;
    }

    @Override
    public void on_user_receive(User u) {
        //UPDATE MANAGER USER

        manager.get_manager().user.name = u.name;
        manager.get_manager().user.last_name = u.last_name;
        manager.get_manager().user.email = u.email;
        manager.get_manager().user.password = u.password;
        manager.get_manager().user.image = u.image;

        Snackbar.make(getView(), "Profile Edited", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();

        NavHostFragment.findNavController(edit_profile_fragment.this).navigate(R.id.action_edit_profile_fragment_to_show_profile_fragment);
    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        menu.findItem(R.id.events_menuButton).setVisible(true);
        menu.findItem(R.id.profile_menuButton).setVisible(false);
        menu.findItem(R.id.users_menuButton).setVisible(false);
        menu.findItem(R.id.friends_menuButton).setVisible(false);
        menu.findItem(R.id.friend_requests_menuButton).setVisible(false);
        menu.findItem(R.id.messages_menuButton).setVisible(false);
        menu.findItem(R.id.logout_menuButton).setVisible(true);
        super.onPrepareOptionsMenu(menu);
    }

}