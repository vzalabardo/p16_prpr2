package com.androidpprog2.proyectolasalle.fragments.users;

import android.content.Context;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.events.main_logged_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.Gson;

import java.util.List;


public class users_fragment extends Fragment implements User_helper.user_listener, User_helper.users_listener {
    private TextInputLayout user_searcher;
    private CountDownTimer countDownTimer = null;

    RecyclerView users_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;

    public users_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_users, container, false);

        //Searcher
        user_searcher = v.findViewById(R.id.user_searcher);

        user_searcher.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                System.out.println(charSequence.toString());
                if(countDownTimer != null){
                    countDownTimer.cancel();
                }
                countDownTimer = new CountDownTimer(750,750) {
                    @Override
                    public void onTick(long l) {

                    }
                    @Override
                    public void onFinish() {
                        System.out.println("Finish timer");
                        User_helper.get_users_by_value(users_fragment.this,context,charSequence.toString());
                    }
                };
                countDownTimer.start();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        //Recycler View
        users_rec_views = v.findViewById(R.id.users_recycler_view);
        users_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        User_helper.get_users(users_fragment.this,context);

        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(),  new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_main_logged_fragment);
            }
        });

        return v;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {

            case R.id.events_menuButton:  {
                NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_main_logged_fragment);
                return true;
            }

            case R.id.profile_menuButton:  {
                System.out.print("Profile Menu ButtonCLICADO");
                Gson g = new Gson();

                Bundle bundle = new Bundle();
                bundle.putString("user",g.toJson(manager.get_manager().user));
                NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_show_profile_fragment,bundle);
                return true;
            }
            case R.id.messages_menuButton:  {
                System.out.print("Messages Menu Button CLICADO");
                NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_messages_fragment);
                return true;
            }
            case R.id.friends_menuButton:  {
                System.out.print("Friends Menu Button CLICADO");
                NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_friends_fragment);
                return true;
            }
            case R.id.friend_requests_menuButton:  {
                System.out.print("Friend Requests Menu Button CLICADO");
                NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_friend_requests_fragment);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void on_user_receive(User u) {
        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("user",g.toJson(u));
        NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_show_profile_fragment,bundle);
    }

    @Override
    public void on_users_receive(List<User> u_list) {
        adapter = new User_adapter(u_list,users_fragment.this);
        users_rec_views.setAdapter(adapter);
    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        menu.findItem(R.id.users_menuButton).setVisible(false);

        super.onPrepareOptionsMenu(menu);
    }

}

