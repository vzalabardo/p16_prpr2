package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.fragments.login.register_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;


public class add_event_fragment extends Fragment implements Event_helper.event_listener {

    private Event event = new Event();
    private EditText event_name;
    private EditText event_image;
    private EditText event_location;
    private EditText event_description;
    private EditText event_startDate;
    private EditText event_endDate;
    private EditText event_maxParticipators;
    private EditText event_type;

    private Button postEventButton;
    private Button backButton;
    private Context context;

    public add_event_fragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_event, container, false);

        //For Visibility Items Options Menu
        getActivity().invalidateOptionsMenu();
        setHasOptionsMenu(true);


        //FIND VIEWS
        event_name = v.findViewById(R.id.event_name_textbox);
        event_image = v.findViewById(R.id.event_image_textbox);
        event_location = v.findViewById(R.id.event_location_textbox);
        event_description = v.findViewById(R.id.event_description_textbox);
        event_startDate = v.findViewById(R.id.event_startDate_textbox);
        event_endDate = v.findViewById(R.id.event_endDate_textbox);
        event_maxParticipators = v.findViewById(R.id.event_maxParticipators_textbox);
        event_type = v.findViewById(R.id.event_type_textbox);

        postEventButton = v.findViewById(R.id.editEvent_button);
        backButton = v.findViewById(R.id.back_postEvent_button);

        //POST EVENT LISTENER
        postEventButton.setOnClickListener(view ->{
            event.name = event_name.getText().toString();
            event.image = event_image.getText().toString();
            event.location = event_location.getText().toString();
            event.description = event_description.getText().toString();
            event.eventStart_date = event_startDate.getText().toString();
            event.eventEnd_date = event_endDate.getText().toString();
            event.n_participators = Integer.parseInt(event_maxParticipators.getText().toString());
            event.type = event_type.getText().toString();

            Event_helper.post_event(event, add_event_fragment.this,context);

        } );

        //BACK BUTTON LSITENER
        backButton.setOnClickListener(view -> NavHostFragment.findNavController(add_event_fragment.this).navigate(R.id.action_add_event_fragment_to_main_logged_fragment));

        //BACK PPRESSED PHONE
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(),  new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed(){
                NavHostFragment.findNavController(add_event_fragment.this).navigate(R.id.action_add_event_fragment_to_main_logged_fragment);
            }
        });

        return v;
    }

    @Override
    public void on_event_receive(Event e) {
        if (e == null){
            Snackbar.make(getView(), "Error Posting Event", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        }
        else{
            Snackbar.make(getView(), "Event Posted!", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            Gson g = new Gson();
            Bundle bundle = new Bundle();
            bundle.putString("event",g.toJson(e));
            NavHostFragment.findNavController(add_event_fragment.this).navigate(R.id.action_add_event_fragment_to_event_details_fragment,bundle);
        }
    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        menu.findItem(R.id.events_menuButton).setVisible(true);
        menu.findItem(R.id.profile_menuButton).setVisible(false);
        menu.findItem(R.id.users_menuButton).setVisible(false);
        menu.findItem(R.id.friends_menuButton).setVisible(false);
        menu.findItem(R.id.friend_requests_menuButton).setVisible(false);
        menu.findItem(R.id.messages_menuButton).setVisible(false);
        menu.findItem(R.id.logout_menuButton).setVisible(true);
        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout_menuButton:  {
                System.out.print("Log Out Menu Button CLICADO");
                manager.get_manager().user = new User();
                NavHostFragment.findNavController(add_event_fragment.this).navigate(R.id.action_add_event_fragment_to_home_fragment);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }

    }

}


