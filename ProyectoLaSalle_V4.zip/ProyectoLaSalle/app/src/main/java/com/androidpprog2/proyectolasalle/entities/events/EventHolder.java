package com.androidpprog2.proyectolasalle.entities.events;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.squareup.picasso.Picasso;

public class EventHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public Event_helper.event_listener onListItemClick;

    public Event event = new Event();
    public ImageView event_image;
    public TextView event_name;
    public TextView event_location;
    public TextView event_date;


    public EventHolder(View v, Event_helper.event_listener onListItemClick) {
        super(v);

        this.onListItemClick = onListItemClick;
        itemView.setOnClickListener(this);
        event_image = itemView.findViewById(R.id.event_image);
        event_name = itemView.findViewById(R.id.event_name);
        event_location = itemView.findViewById(R.id.event_location);
        event_date = itemView.findViewById(R.id.event_date);

        //((View) event_location.getParent()).setOnClickListener(this);

    }

    public void fill_holder_fields(Event e){
        event = e;
        event_name.setText(event.name);
        event_location.setText(event.location);
        try { Picasso.get().load(event.image).into(event_image); }
        catch(Exception exp) { System.out.println(exp); }
    }

    @Override
    public void onClick(View view) {
        onListItemClick.on_event_receive(event);
    }
}
