package com.androidpprog2.proyectolasalle.fragments.messages;

import android.content.Context;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.messages.Message;
import com.androidpprog2.proyectolasalle.entities.messages.Message_adapter;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.events.event_details_fragment;
import com.androidpprog2.proyectolasalle.fragments.events.main_logged_fragment;
import com.androidpprog2.proyectolasalle.fragments.users.show_profile_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import java.util.List;


public class conversation_fragment extends Fragment implements Message_helper.messages_receive_listener, Message_helper.message_send_listener {
    RecyclerView messages_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;
    private User user = new User();
    private EditText user_message;
    private Button sendmessageButton;
    private CountDownTimer countDownTimer = null;


    public conversation_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_conversation, container, false);

        if (getArguments() != null){
            Gson g = new Gson();
            user = g.fromJson(getArguments().getString("user"), User.class);
        }


        messages_rec_views = v.findViewById(R.id.messages_recycler_view);
        messages_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));
        user_message = v.findViewById(R.id.user_message_conversation);
        sendmessageButton = v.findViewById(R.id.SendMessagebutton);

        Message_helper.get_messages_by_user_id(conversation_fragment.this,context, String.valueOf(user.id));

        sendmessageButton.setOnClickListener(view -> {
            Message message = new Message();

            message.content = user_message.getText().toString();
            message.user_id_send = manager.get_manager().user.id;
            message.user_id_recived = user.id;

            Message_helper.post_message(message,conversation_fragment.this,context,v);

        });

        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(),  new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_messages_fragment);
            }
        });


        return v;
    }



    @Override
    public void on_messages_receive_listener(List<Message> m_list) {
        System.out.println("GOT MESSAGES");
        adapter = new Message_adapter(m_list);
        messages_rec_views.setAdapter(adapter);
        adapter.notifyDataSetChanged();


        //TIMER QUE SE DEDICARA A IR LLAMANDO A get_messages_by_user_id PARA RECARGAR LA CONVERSACION
        if(countDownTimer != null){
            countDownTimer.cancel();
        }

        countDownTimer = new CountDownTimer(10000,10000) {
            @Override
            public void onTick(long l) {

            }
            @Override
            public void onFinish() {
                System.out.println("Reloading Messages");
                Message_helper.get_messages_by_user_id(conversation_fragment.this,context, String.valueOf(user.id));
                countDownTimer.cancel();
            }
        };
        countDownTimer.start();

    }

    @Override
    public void on_message_send(View v) {
        Snackbar.make(v, "Message Sent", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        user_message.setText("");

        Message_helper.get_messages_by_user_id(conversation_fragment.this,context, String.valueOf(user.id));

    }

    @Override
    public void on_message_error(View v) {
        Snackbar.make(v, "Message Error", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile_menuButton:  {
                System.out.print("Profile Menu ButtonCLICADO");
                Gson g = new Gson();

                Bundle bundle = new Bundle();
                bundle.putString("user",g.toJson(manager.get_manager().user));
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_show_profile_fragment,bundle);
                return true;
            }
            case R.id.users_menuButton:  {
                System.out.print("Users Menu Button CLICADO");
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_users_fragment);
                return true;
            }
            case R.id.messages_menuButton:  {
                System.out.print("Messages Menu Button CLICADO");
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_messages_fragment);
                return true;
            }
            case R.id.friends_menuButton:  {
                System.out.print("Friends Menu Button CLICADO");
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_friends_fragment);
                return true;
            }
            case R.id.friend_requests_menuButton:  {
                System.out.print("Friend Requests Menu Button CLICADO");
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_friend_requests_fragment);
                return true;
            }
            case R.id.logout_menuButton:  {
                System.out.print("Log Out Menu Button CLICADO");
                manager.get_manager().user = new User();
                NavHostFragment.findNavController(conversation_fragment.this).navigate(R.id.action_conversation_fragment_to_home_fragment);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }

    }

}