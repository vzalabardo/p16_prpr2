package com.androidpprog2.proyectolasalle.helpers;

import android.content.Context;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.androidpprog2.proyectolasalle.entities.Statistic;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.manager;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class User_helper {
    public interface user_listener{
        void on_user_receive(User u);
    }
    public interface users_listener{
        void on_users_receive(List<User> u_list);
    }
    public interface user_assistances_listener{
        void on_user_assistances_receive(List<Event> u_list);
    }
    public interface user_events_listener{
        void on_user_events_receive(List<Event> e_list);
    }
    public interface friends_listener{
        void on_friends_receive(List<User> u_list);
    }
    public interface user_send_request_listener{
        void on_user_request_post(View v);
    }
    public interface user_accept_request_listener{
        void on_user_request_accept();
    }
    public interface user_delete_listener{
        void on_user_delete();
    }
    public interface user_request_receive {
        void on_user_accept_receive(User u);
        void on_user_decline_receive(User u);
    }
    public interface user_statistic_receive {
        void on_user_statistic_receive(Statistic s);
    }


        //USER REGISTER
    static public void register(User u, user_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "users";
        System.out.println(url);

        RequestQueue queue = Volley.newRequestQueue(context);

        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("name",u.name);
            JSON_user.put("last_name",u.last_name);
            JSON_user.put("email",u.email);
            JSON_user.put("password",u.password);
            JSON_user.put("image",u.image);
        }
        catch (JSONException e) {
            e.printStackTrace();}

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, JSON_user,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("respuesta", "Registro de usuario correcto: "+ response.toString());
                        u_listener.on_user_receive(u);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Gson g = new Gson();
                        Log.e("respuesta", "Registro de usuario error:" + g.toJson(error));
                }
                });
        queue.add(jsonObjReq);
    }

    //USER EDIT PROFILE
    static public void edit_profile(User u, user_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "users";
        System.out.println(url);

        RequestQueue queue = Volley.newRequestQueue(context);
        //TODO: JSON OBJECT TO JSON ARRAY
        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("name",u.name);
            JSON_user.put("last_name",u.last_name);
            JSON_user.put("email",u.email);
            if(!u.password.isEmpty()) {
                JSON_user.put("password", u.password);
            }
            JSON_user.put("image",u.image);}

        //JSON_user.put("image","https://img.freepik.com/vector-gratis/perfil-avatar-hombre-icono-redondo_24640-14044.jpg");}
        catch (JSONException e) {
            e.printStackTrace();}


        JsonObjectRequest jsonArrayRequest = new JsonObjectRequest
                (Request.Method.PUT, url, JSON_user, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "La resposta es: "+ response.toString());

                        Gson g = new Gson();
                        User u = g.fromJson(response.toString(), User.class);
                        u_listener.on_user_receive(u);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Gson g = new Gson();
                        Log.e("respuesta", "Modificacion de usuario error:" + g.toJson(error));

                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> headers = new HashMap<>();
                        String token = manager.get_manager().user.accesToken;
                        headers.put("Authorization", "Bearer " + token);
                        return headers;
        }};
        queue.add(jsonArrayRequest);
    }

     //USER LOGIN
    static public void login(User u, user_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "users/login";
        //u_listener.on_user_receive(u);
        RequestQueue queue = Volley.newRequestQueue(context);

        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("email",u.email);
            JSON_user.put("password",u.password);}
        catch (JSONException e) {
            e.printStackTrace();}

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, JSON_user,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println(response.toString());
                        String token = "";
                        try {
                            token = response.getString("accessToken");
                            System.out.println(token);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //ASSIGN MANAGER USER ACCESTOKEN
                        u.accesToken = token;
                        u_listener.on_user_receive(u);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("respuesta", "Login de usuario error:" + error);
                        u_listener.on_user_receive(u);
                    }
        });
        queue.add(jsonObjReq);

    }

    //GET USERS
    static public void get_users(users_listener users_listener,Context context){
        String url = manager.get_manager().url_api + "users";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA USERS: "+ response.toString());

                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        users_listener.on_users_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA USERS ERROR:" + error);
                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> headers = new HashMap<>();
                        String token = manager.get_manager().user.accesToken;
                        headers.put("Authorization", "Bearer " + token);
                        return headers;
        }};
        queue.add(jsonObjectRequest);
    }

    //GET USER BY ID
    static public void get_user_by_id(user_listener u_listener, Context context, String id){
        String url = manager.get_manager().url_api + "users/" + id;
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "Respuesta USER BY ID: "+ response.toString());
                        JSONObject responseJsonObject = null;
                        try {
                            responseJsonObject = response.getJSONObject(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Gson g = new Gson();
                        User u = g.fromJson(responseJsonObject.toString(), User.class);
                        u_listener.on_user_receive(u);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "ERROR USER BY ID:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonArrayRequest);

    }

    //GET/SEARCH USER BY VALUE
    static public void get_user_by_value(user_listener u_listener, Context context, String s){ //Name, last_name, email
        String url = manager.get_manager().url_api + "users/search" + "?s=" + s;
        RequestQueue queue = Volley.newRequestQueue(context);

        /*
        if( s.isEmpty()){
            u_listener.on_user_receive(manager.get_manager().u_list);
            return
        }*/

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "USER BY VALUE: "+ response.toString());
                        JSONObject responseJsonObject = null;
                        try {
                            responseJsonObject = response.getJSONObject(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Gson g = new Gson();
                        User u = g.fromJson(responseJsonObject.toString(), User.class);
                        u_listener.on_user_receive(u);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "USER BY VALUE ERROR:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonArrayRequest);
    }
    //GET/SEARCH USER BY VALUE
    static public void get_users_by_value(users_listener users_listener, Context context, String s){ //Name, last_name, email
        String url = manager.get_manager().url_api + "users/search" + "?s=" + s;
        RequestQueue queue = Volley.newRequestQueue(context);


        if( s.isEmpty()){
            users_listener.on_users_receive(manager.get_manager().u_list);
            return;
        }

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "USER BY VALUE: "+ response.toString());
                        JSONObject responseJsonObject = null;
                        try {
                            responseJsonObject = response.getJSONObject(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        users_listener.on_users_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "USER BY VALUE ERROR:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonArrayRequest);
    }
    //GET USER STATISTICS
    static public void get_user_statistics(user_statistic_receive user_statistic_receive,Context context,String id){
        String url = manager.get_manager().url_api + "users/" + id + "/statistics";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjReq = new JsonArrayRequest(
                Request.Method.GET,url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("respuesta", "User Statistics Correct: "+ response.toString());
                        Gson g = new Gson();
                        //Statistic s = g.fromJson(response.toString(), Statistic.class);
                        List<Statistic> s_list = Arrays.asList(g.fromJson(response.toString(), (Type) Statistic[].class));
                        user_statistic_receive.on_user_statistic_receive(s_list.get(0));

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("respuesta", "User Statistics Error:" + error.toString());
            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjReq);
    }


    //GET USER EVENTS
    static public void get_user_events(user_events_listener user_events_listener,Context context, String id){
        String url = manager.get_manager().url_api + "users/" + id + "/events";

        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA USER EVENTS CORRECTA: "+ response.toString());

                        Gson g = new Gson();
                        List<Event> e_list = Arrays.asList(g.fromJson(response.toString(), (Type) Event[].class));
                        user_events_listener.on_user_events_receive(e_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA USER EVENTS ERROR:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    //GET USER EVENTS FUTURE
    static public void get_user_events_future(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/events/future";
    }

    //GET USER EVENTS FINISHED
    static public void get_user_events_finished(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/events/finished";
    }

    //GET USER ASSISTANCES
    static public void get_user_assistances(user_assistances_listener user_assistances_listener,Context context,String id){
        String url = manager.get_manager().url_api + "users/" + id + "/assistances";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA USER ASSISTANCES: "+ response.toString());

                        Gson g = new Gson();
                        List<Event> e_list = Arrays.asList(g.fromJson(response.toString(), (Type) Event[].class));
                        user_assistances_listener.on_user_assistances_receive(e_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA ERROR USER ASSISTACNES:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }


    //GET USER ASSISTANCES FUTURE
    static public void get_user_assistances_future(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/assistances/future";
    }

    //GET USER ASSISTANCES FINISHED
    static public void get_user_assistances_finished(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/assistances/finished";
    }

    //GET USER FRIENDS
    static public void get_user_friends(friends_listener friends_listener,Context context){
        String url = manager.get_manager().url_api + "friends";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA USER FRIENDS: "+ response.toString());

                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        friends_listener.on_friends_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA USER FRIENDS ERROR:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);

    }

    static public void send_friend_request(user_send_request_listener user_send_request_listener, Context context, View v, String id){
        String url = manager.get_manager().url_api + "friends/" + id ;

        RequestQueue queue = Volley.newRequestQueue(context);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "Friend Request Correct: "+ response.toString());
                        user_send_request_listener.on_user_request_post(v);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Friend Request Error:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    static public void get_user_friend_requests(users_listener users_listener,Context context){
        String url = manager.get_manager().url_api + "friends/requests";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA USER FRIENDS REQUESTS: "+ response.toString());

                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        users_listener.on_users_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA USER FRIENDS REQUESTS ERROR:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);

    }

    static public void accept_friend_request(user_accept_request_listener user_accept_request_listener, Context context, String id){
        String url = manager.get_manager().url_api + "friends/" + id ;

        RequestQueue queue = Volley.newRequestQueue(context);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.PUT, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "Friend Request Accept Correct: "+ response.toString());
                        user_accept_request_listener.on_user_request_accept();
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Friend Request Accept Error:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    static public void delete_friend(user_delete_listener user_delete_listener, Context context, String id){
        String url = manager.get_manager().url_api + "friends/" + id ;

        RequestQueue queue = Volley.newRequestQueue(context);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.DELETE, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "Friend Delete Correct: "+ response.toString());
                        user_delete_listener.on_user_delete();
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Friend Delete Error:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }
}
