package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.graphics.Paint;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.users.show_profile_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.util.List;

public class event_details_fragment extends Fragment implements Event_helper.event_assistances_listener,Event_helper.event_assistance_listener, User_helper.user_listener,Event_helper.event_cancel_assistance_listener, User_helper.user_events_listener {
    RecyclerView users_event_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;
    private Event event = new Event();
    private List<User> u_ass_list;

    private TextView event_name;
    private TextView event_location;
    private TextView event_type;
    private ImageView event_image;
    private TextView event_description;
    private TextView event_nParticipators;
    private TextView event_startDate;
    private TextView event_endDate;
    private TextView event_Date;

    private Button JoinButton;
    private Button CancelButton;
    private Button RateButton;
    private Button EditButton;


    public event_details_fragment() {
        // Required empty public constructor
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_event_details, container, false);

        if (getArguments() != null){
            Gson g = new Gson();
            event = g.fromJson(getArguments().getString("event"),Event.class);
            System.out.println(event.name);
        }

        getActivity().invalidateOptionsMenu();
        setHasOptionsMenu(true);

        Event_helper.get_event_assistances(event_details_fragment.this, this.context, String.valueOf(event.id));
        User_helper.get_user_events(event_details_fragment.this,context,String.valueOf(manager.get_manager().user.id));


        //FIND VIEWS
        users_event_rec_views = v.findViewById(R.id.events_user_recycler_view);
        users_event_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        event_name = v.findViewById(R.id.event_name);
        event_location = v.findViewById(R.id.event_location);
        event_type = v.findViewById(R.id.event_type);
        event_image = v.findViewById(R.id.event_image);
        event_description = v.findViewById(R.id.event_description);
        event_nParticipators = v.findViewById(R.id.event_nParticipators);
        event_startDate = v.findViewById(R.id.eventStart_date);
        event_endDate = v.findViewById(R.id.eventEnd_date);
        event_Date = v.findViewById(R.id.event_date);
        JoinButton = v.findViewById(R.id.JoinButton);
        CancelButton = v.findViewById(R.id.cancelEventButton);
        RateButton = v.findViewById(R.id.RateButton);
        EditButton = v.findViewById(R.id.EditButton);

        //FILL EVENT TEXT FIELDS
        event_name.setText(event.name);
        event_location.setText((event.location));
        event_type.setText(event.type);
        try{ Picasso.get().load(event.image).into(event_image);}
        catch (Exception e) { e.printStackTrace();}
        event_description.setText(event.description);
        event_nParticipators.setText("Max Assistants: " + String.valueOf(event.n_participators));
        event_startDate.setText("Start Date \n" + event.eventStart_date);
        event_endDate.setText("End Date: \n" + event.eventEnd_date);
        event_Date.setText("Creation Date \n: " + event.date);


        if(event.owner_id == manager.get_manager().user.id){ EditButton.setVisibility(View.VISIBLE); }

        JoinButton.setOnClickListener(view-> {
            Event_helper.post_assistance(event_details_fragment.this,context,v,String.valueOf(event.id));
        });

        CancelButton.setOnClickListener(view -> {
            Event_helper.cancel_assistance(event_details_fragment.this,context,v,String.valueOf(event.id));
        });

        RateButton.setOnClickListener(view -> {
            Bundle bundle = new Bundle();
            bundle.putInt("id",event.id);

            NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_rate_event_fragment2,bundle);
        });

        EditButton.setOnClickListener(view -> {
            Gson g = new Gson();
            Bundle bundle = new Bundle();
            bundle.putString("event",g.toJson(event));
            NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_edit_event_fragment,bundle);
        });

        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(),  new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_main_logged_fragment);
            }
        });

        return v;
    }


    @Override
    public void on_event_assistances_receive(List<User> u_ass_list) {
        //LOAD USERS RECYCLE VIEW
        //TODO: CONSEGUIR IMAGE URL
        for(User u : u_ass_list)
        {
            if(u.id == manager.get_manager().user.id){
                JoinButton.setVisibility(View.GONE);
                CancelButton.setVisibility(View.VISIBLE);
            }
            else{
                JoinButton.setVisibility(View.VISIBLE);
                CancelButton.setVisibility(View.GONE);
            }
        }
        for(User u: u_ass_list){
            for(User u2: manager.get_manager().u_list){
                if(u.id == u2.id){
                    u.image = u2.image;
                }
            }
        }

        adapter = new User_adapter(u_ass_list, event_details_fragment.this);
        users_event_rec_views.setAdapter(adapter);
    }

    @Override
    public void on_user_receive(User u) {

        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("user",g.toJson(u));
        NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_show_profile_fragment,bundle);
    }

    @Override
    public void on_event_assistances_post(View v) {
        Event_helper.get_event_assistances(event_details_fragment.this, this.context, String.valueOf(event.id));

        Snackbar.make(v, "Joined Event!", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void on_event_cancel_assistances_post(View v) {
        Event_helper.get_event_assistances(event_details_fragment.this, this.context, String.valueOf(event.id));

        Snackbar.make(v, "Event Canceled!", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void on_user_events_receive(List<Event> e_list) {
        for(Event e: e_list){
            if(e.id == event.id){
                EditButton.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile_menuButton:  {
                System.out.print("Profile Menu ButtonCLICADO");
                Gson g = new Gson();

                Bundle bundle = new Bundle();
                bundle.putString("user",g.toJson(manager.get_manager().user));
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_show_profile_fragment,bundle);
                return true;
            }
            case R.id.users_menuButton:  {
                System.out.print("Users Menu Button CLICADO");
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_users_fragment);
                return true;
            }
            case R.id.messages_menuButton:  {
                System.out.print("Messages Menu Button CLICADO");
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_messages_fragment);
                return true;
            }
            case R.id.friends_menuButton:  {
                System.out.print("Friends Menu Button CLICADO");
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_friends_fragment);
                return true;
            }
            case R.id.friend_requests_menuButton:  {
                System.out.print("Friend Requests Menu Button CLICADO");
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_friend_requests_fragment);
                return true;
            }
            case R.id.logout_menuButton:  {
                System.out.print("Log Out Menu Button CLICADO");
                manager.get_manager().user = new User();
                NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_home_fragment);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void onPrepareOptionsMenu(@NonNull Menu menu) {
        menu.findItem(R.id.friend_requests_menuButton).setVisible(false);
        super.onPrepareOptionsMenu(menu);
    }

}