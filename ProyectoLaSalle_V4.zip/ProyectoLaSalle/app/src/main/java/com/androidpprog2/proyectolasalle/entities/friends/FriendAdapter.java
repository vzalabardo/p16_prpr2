package com.androidpprog2.proyectolasalle.entities.friends;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.UserHolder;
import com.androidpprog2.proyectolasalle.helpers.User_helper;

import java.util.List;

public class FriendAdapter extends RecyclerView.Adapter<FriendHolder>   {

    private List<User> u_list;
    private User_helper.user_request_receive onAcceptClick;;
    private User_helper.user_request_receive onDeclineClick;;

    public FriendAdapter(List<User> u_list, User_helper.user_request_receive onAcceptClick, User_helper.user_request_receive onDeclineClick) {
        this.u_list = u_list;
        this.onAcceptClick = onAcceptClick;
        this.onDeclineClick = onDeclineClick;
    }

    @Override
    public FriendHolder onCreateViewHolder(ViewGroup container, int viewType) {
        View v = LayoutInflater.from(container.getContext()).inflate(R.layout.firend_request_item, container, false);
        return new FriendHolder(v,onAcceptClick,onDeclineClick);
    }

    @Override
    public void onBindViewHolder(@NonNull FriendHolder holder, int position) {
        holder.fill_holder_fields(u_list.get(position));
    }

    @Override
    public int getItemCount() {
        return u_list.size();
    }
}
