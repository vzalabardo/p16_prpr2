package com.androidpprog2.proyectolasalle.entities;

public class Assistance {
    public int user_id = 0;
    public int event_id = 0;
    public int puntuation = 0;
    public String comentary = "";

}
