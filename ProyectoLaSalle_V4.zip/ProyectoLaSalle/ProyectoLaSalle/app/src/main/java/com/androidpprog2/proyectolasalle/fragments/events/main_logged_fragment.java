package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.events.Event_adapter;
import com.androidpprog2.proyectolasalle.fragments.login.login_fragment;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class main_logged_fragment extends Fragment implements Event_helper.events_listener, Generic_helper.OnListItemClick {

    RecyclerView events_rec_views;
    RecyclerView.Adapter adapter;

    private FloatingActionButton addEventButton;
    private Context context;
    ArrayList<Event> e_list;

    public main_logged_fragment() {
        // Required empty public constructor
    }
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_main_logged_fragment, container, false);

        Event_helper.get_events(main_logged_fragment.this,context);

        //FIND VIEWS
        events_rec_views = v.findViewById(R.id.events_recycler_view);
        events_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));
        addEventButton = v.findViewById(R.id.add_event_button);

        //addEventButton
        addEventButton.setOnClickListener(view -> NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_add_event_fragment));

        return v;
    }
    /*
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_bar, menu);
    }*/

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.profile_menuButton:  {
                System.out.print("PROFILE CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_show_profile_fragment);
                return true;
            }
            case R.id.users_menuButton:  {
                System.out.print("PROFILE CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_users_fragment);
                return true;
            }
            case R.id.eventoprueba_menuButton:  {
                System.out.print("Evento CLICADO");
                NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_event_details_fragment);
                return true;
            }
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    public void on_events_receive(List<Event> e_list){
        manager.get_manager().e_list = e_list;

        //LOAD EVENT RECYCLE VIEW

        adapter = new Event_adapter(manager.get_manager().e_list,main_logged_fragment.this);
        events_rec_views.setAdapter(adapter);

    }

    @Override
    public void onClick(View view, int event_id) {
        System.out.println(event_id);
        Bundle bundle = new Bundle();
        bundle.putInt("id",event_id);
        NavHostFragment.findNavController(main_logged_fragment.this).navigate(R.id.action_main_logged_fragment_to_event_details_fragment,bundle);
    }
}