package com.androidpprog2.proyectolasalle.helpers;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.manager;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class User_helper {
    public interface user_listener{
        void on_user_receive(User u);
    }
    public interface users_listener{
        void on_users_receive(List<User> u_list);
    }

    //USER REGISTER
    static public void register(User u, user_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "users";
        System.out.println(url);

        RequestQueue queue = Volley.newRequestQueue(context);

        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("name",u.name);
            JSON_user.put("last_name",u.last_name);
            JSON_user.put("email",u.email);
            JSON_user.put("password",u.password);
            JSON_user.put("image",u.image);}
        catch (JSONException e) {
            e.printStackTrace();}

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, JSON_user,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("respuesta", "Registro de usuario correcto: "+ response.toString());
                        u_listener.on_user_receive(u);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("respuesta", "Registro de usuario error:" + error);
                        u_listener.on_user_receive(u);
                }
                });
        queue.add(jsonObjReq);
    }

    //USER EDIT PROFILE
    static public void edit_profile(User u, user_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "users";
        System.out.println(url);

        RequestQueue queue = Volley.newRequestQueue(context);
        //TODO: JSON OBJECT TO JSON ARRAY
        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("name",u.name);
            JSON_user.put("last_name",u.last_name);
            JSON_user.put("email",u.email);
            JSON_user.put("password",u.password);
            JSON_user.put("image",u.image);}
        catch (JSONException e) {
            e.printStackTrace();}


        JsonObjectRequest jsonArrayRequest = new JsonObjectRequest
                (Request.Method.PUT, url, JSON_user, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "La resposta es: "+ response.toString());

                        Gson g = new Gson();
                        User u = g.fromJson(response.toString(), User.class);
                        u_listener.on_user_receive(u);
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("respuesta", "Modificacion de usuario error:" + error);
                        u_listener.on_user_receive(u);
                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> headers = new HashMap<>();
                        String token = manager.get_manager().user.accesToken;
                        headers.put("Authorization", "Bearer " + token);
                        return headers;
        }};
        queue.add(jsonArrayRequest);
    }

     //USER LOGIN
    static public void login(User u, user_listener u_listener, Context context){
        String url = manager.get_manager().url_api + "users/login";
        //u_listener.on_user_receive(u);
        RequestQueue queue = Volley.newRequestQueue(context);

        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("email",u.email);
            JSON_user.put("password",u.password);}
        catch (JSONException e) {
            e.printStackTrace();}

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, JSON_user,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        System.out.println(response.toString());
                        String token = "";
                        try {
                            token = response.getString("accessToken");
                            System.out.println(token);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //ASSIGN MANAGER USER ACCESTOKEN
                        manager.get_manager().user.accesToken = token;
                        manager.get_manager().user.email = u.email;
                        manager.get_manager().user.password = u.password;
                        u_listener.on_user_receive(u);

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("respuesta", "Login de usuario error:" + error);
                        u_listener.on_user_receive(u);
                    }
        });
        queue.add(jsonObjReq);

    }

    //GET USERS
    static public void get_users(users_listener users_listener,Context context){
        String url = manager.get_manager().url_api + "users";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA EVENTOS: "+ response.toString());

                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        users_listener.on_users_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA ERROR EVENTOS:" + error);
                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> headers = new HashMap<>();
                        String token = manager.get_manager().user.accesToken;
                        headers.put("Authorization", "Bearer " + token);
                        return headers;
        }};
        queue.add(jsonObjectRequest);
    }

    //GET USER BY ID
    static public void get_user_by_id(String id){
        String url = manager.get_manager().url_api + "users/" + id;

    }

    //GET/SEARCH USER BY VALUE
    static public void get_user_by_value(user_listener u_listener, Context context, String s){ //Name, last_name, email
        String url = manager.get_manager().url_api + "users/search" + "?s=" + s;
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "La resposta es: "+ response.toString());
                        JSONObject responseJsonObject = null;
                        try {
                            responseJsonObject = response.getJSONObject(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Gson g = new Gson();
                        User u = g.fromJson(responseJsonObject.toString(), User.class);
                        u_listener.on_user_receive(u);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Hi ha hagut un error:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonArrayRequest);
    }

    //GET USER STATISTICS
    static public void get_user_statistics(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/statistics";
    }

    //GET USER EVENTS
    static public void get_user_events(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/events";
    }

    //GET USER EVENTS FUTURE
    static public void get_user_events_future(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/events/future";
    }

    //GET USER EVENTS FINISHED
    static public void get_user_events_finished(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/events/finished";
    }

    //GET USER ASSISTANCES
    static public void get_user_assistances(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/assistances";
    }

    //GET USER ASSISTANCES FUTURE
    static public void get_user_assistances_future(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/assistances/future";
    }

    //GET USER ASSISTANCES FINISHED
    static public void get_user_assistances_finished(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/assistances/finished";
    }

    //GET USER FRIENDS
    static public void get_user_friends(String id){
        String url = manager.get_manager().url_api + "users/" + id + "/friends";
    }
    

}
