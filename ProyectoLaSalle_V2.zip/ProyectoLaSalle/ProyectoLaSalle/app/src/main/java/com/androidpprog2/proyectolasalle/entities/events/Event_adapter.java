package com.androidpprog2.proyectolasalle.entities.events;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;


import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.squareup.picasso.Picasso;

import java.util.List;
public class Event_adapter extends RecyclerView.Adapter<EventHolder> {

    private List<Event> e_list;
    private Generic_helper.OnListItemClick onListItemClick;


    public Event_adapter(List<Event> e_list, Generic_helper.OnListItemClick onListItemClick){
        this.e_list = e_list;
        this.onListItemClick = onListItemClick;
    }

    public EventHolder onCreateViewHolder(ViewGroup container, int viewType){
        View v = LayoutInflater.from(container.getContext()).inflate(R.layout.event_item, container, false);
        return new EventHolder(v,onListItemClick);
    }

    @Override
    public void onBindViewHolder(EventHolder holder, int position) {
        holder.event_id = e_list.get(position).id;
        holder.event_name.setText(e_list.get(position).name);
        holder.event_location.setText(e_list.get(position).location);
        Picasso.get().load(e_list.get(position).image).into(holder.event_image);
    }

    @Override
    public int getItemCount() {
        return e_list.size();
    }

}
