package com.androidpprog2.proyectolasalle.entities;

public class Friend {
    String friend = "";
}
