package com.androidpprog2.proyectolasalle.fragments.events;

import android.content.Context;
import android.graphics.Paint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.util.List;

public class event_details_fragment extends Fragment implements Event_helper.event_assistances_listener,Event_helper.event_assistance_listener, User_helper.user_listener,Event_helper.event_cancel_assistance_listener {
    RecyclerView users_event_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;
    private Event event = new Event();
    private List<User> u_ass_list;

    private TextView event_name;
    private TextView event_location;
    private TextView event_type;
    private ImageView event_image;
    private TextView event_description;
    private TextView event_nParticipators;
    private TextView event_startDate;
    private TextView event_endDate;
    private TextView event_Date;

    private Button JoinButton;
    private Button CancelButton;


    public event_details_fragment() {
        // Required empty public constructor
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_event_details, container, false);

        if (getArguments() != null){
            Gson g = new Gson();
            event = g.fromJson(getArguments().getString("event"),Event.class);
            System.out.println(event.name);
        }

        Event_helper.get_event_assistances(event_details_fragment.this, this.context, String.valueOf(event.id));

        //FIND VIEWS
        users_event_rec_views = v.findViewById(R.id.events_user_recycler_view);
        users_event_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        event_name = v.findViewById(R.id.event_name);
        event_location = v.findViewById(R.id.event_location);
        event_type = v.findViewById(R.id.event_type);
        event_image = v.findViewById(R.id.event_image);
        event_description = v.findViewById(R.id.event_description);
        event_nParticipators = v.findViewById(R.id.event_nParticipators);
        event_startDate = v.findViewById(R.id.eventStart_date);
        event_endDate = v.findViewById(R.id.eventEnd_date);
        event_Date = v.findViewById(R.id.event_date);
        JoinButton = v.findViewById(R.id.JoinButton);
        CancelButton = v.findViewById(R.id.cancelEventButton);

        //FILL EVENT TEXT FIELDS
        event_name.setText(event.name);
        event_location.setText((event.location));
        event_type.setText(event.type);
        try{ Picasso.get().load(event.image).into(event_image);}
        catch (Exception e) { e.printStackTrace();}
        event_description.setText(event.description);
        event_nParticipators.setText("Max Assistants: " + String.valueOf(event.n_participators));
        event_startDate.setText("Start Date \n" + event.eventStart_date);
        event_endDate.setText("End Date: \n" + event.eventEnd_date);
        event_Date.setText("Creation Date \n: " + event.date);

        JoinButton.setOnClickListener(view-> {
            Event_helper.post_assistance(event_details_fragment.this,context,v,String.valueOf(event.id));
        });

        CancelButton.setOnClickListener(view -> {
            Event_helper.cancel_assistance(event_details_fragment.this,context,v,String.valueOf(event.id));
        });


        return v;
    }


    @Override
    public void on_event_assistances_receive(List<User> u_ass_list) {
        //LOAD USERS RECYCLE VIEW
        //TODO: CONSEGUIR IMAGE URL
        for(User u : u_ass_list)
        {
            if(u.id == manager.get_manager().user.id){
                JoinButton.setVisibility(View.GONE);
                CancelButton.setVisibility(View.VISIBLE);
            }
            else{
                JoinButton.setVisibility(View.VISIBLE);
                CancelButton.setVisibility(View.GONE);
            }
        }

        adapter = new User_adapter(u_ass_list, event_details_fragment.this);
        users_event_rec_views.setAdapter(adapter);
    }

    @Override
    public void on_user_receive(User u) {

        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("user",g.toJson(u));
        NavHostFragment.findNavController(event_details_fragment.this).navigate(R.id.action_event_details_fragment_to_show_profile_fragment,bundle);
    }

    @Override
    public void on_event_assistances_post(View v) {
        Event_helper.get_event_assistances(event_details_fragment.this, this.context, String.valueOf(event.id));

        Snackbar.make(v, "Joined Event!", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void on_event_cancel_assistances_post(View v) {
        Event_helper.get_event_assistances(event_details_fragment.this, this.context, String.valueOf(event.id));

        Snackbar.make(v, "Event Canceled!", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        adapter.notifyDataSetChanged();
    }
}