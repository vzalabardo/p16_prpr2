package com.androidpprog2.proyectolasalle.entities;

public class Statistic {
    public String avg_score = "";
    public int num_comments = 0;
    public String percentage_commenters_below = "";
}
