package com.androidpprog2.proyectolasalle.fragments.users;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.events.main_logged_fragment;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.google.gson.Gson;

import java.util.List;


public class users_fragment extends Fragment implements User_helper.user_listener {
    RecyclerView users_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;

    public users_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_users, container, false);

        users_rec_views = v.findViewById(R.id.users_recycler_view);
        users_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new User_adapter(manager.get_manager().u_list,users_fragment.this);
        users_rec_views.setAdapter(adapter);

        return v;
    }


    @Override
    public void on_user_receive(User u) {
        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("user",g.toJson(u));
        NavHostFragment.findNavController(users_fragment.this).navigate(R.id.action_users_fragment_to_show_profile_fragment,bundle);
    }

}