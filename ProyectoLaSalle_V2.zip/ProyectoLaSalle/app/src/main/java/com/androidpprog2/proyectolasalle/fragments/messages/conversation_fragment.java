package com.androidpprog2.proyectolasalle.fragments.messages;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.messages.Message;
import com.androidpprog2.proyectolasalle.entities.messages.Message_adapter;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;
import com.google.gson.Gson;

import java.util.List;


public class conversation_fragment extends Fragment implements Message_helper.messages_receive_listener {
    RecyclerView messages_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;
    private User user = new User();

    public conversation_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_conversation, container, false);

        if (getArguments() != null){
            Gson g = new Gson();
            user = g.fromJson(getArguments().getString("user"), User.class);
        }


        messages_rec_views = v.findViewById(R.id.messages_recycler_view);
        messages_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        Message_helper.get_messages_by_user_id(conversation_fragment.this,context, String.valueOf(user.id));

        return v;
    }



    @Override
    public void on_messages_receive_listener(List<Message> m_list) {
        adapter = new Message_adapter(m_list);
        messages_rec_views.setAdapter(adapter);
    }
}