package com.androidpprog2.proyectolasalle.entities.friends;

public class FriendHolder {
}
