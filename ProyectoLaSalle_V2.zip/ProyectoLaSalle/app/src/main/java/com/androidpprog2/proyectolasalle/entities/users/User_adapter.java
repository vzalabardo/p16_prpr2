package com.androidpprog2.proyectolasalle.entities.users;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;


import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.helpers.Generic_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.squareup.picasso.Picasso;

import java.util.List;

public class User_adapter extends RecyclerView.Adapter<UserHolder> {

    private List<User> u_list;
    private User_helper.user_listener onListItemClick;;

    public User_adapter(List<User> u_list, User_helper.user_listener onListItemClick) {
        this.u_list = u_list;
        this.onListItemClick = onListItemClick;
        }

    @Override
    public UserHolder onCreateViewHolder(ViewGroup container, int viewType) {
        View v = LayoutInflater.from(container.getContext()).inflate(R.layout.user_item, container, false);
        return new UserHolder(v,onListItemClick);
    }

    @Override
    public void onBindViewHolder(UserHolder holder, int position) {
        holder.fill_holder_fields(u_list.get(position));
    }

    @Override
    public int getItemCount() {
        return u_list.size();
    }
}
