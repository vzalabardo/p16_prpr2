package com.androidpprog2.proyectolasalle.entities.messages;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.events.EventHolder;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;

import java.util.List;

public class Message_adapter extends RecyclerView.Adapter<MessageHolder> {

    public List<Message> m_list;

    public Message_adapter(List<Message> m_list){
        this.m_list = m_list;
    }

    @Override
    public MessageHolder onCreateViewHolder(ViewGroup container, int viewType){
        View v = LayoutInflater.from(container.getContext()).inflate(R.layout.message_item, container, false);
        return new MessageHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull MessageHolder holder, int position) {
        holder.fill_holder_fields(m_list.get(position));
    }

    @Override
    public int getItemCount() { return m_list.size();}

}
