package com.androidpprog2.proyectolasalle.fragments.login;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.androidpprog2.proyectolasalle.R;

public class home_fragment extends Fragment {

    private Button mLoginButton;
    private Button mRegisterButton;

    public home_fragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v = inflater.inflate(R.layout.fragment_home, container, false);

        mLoginButton = (Button) v.findViewById(R.id.login_button);
        mLoginButton.setOnClickListener(view -> NavHostFragment.findNavController(home_fragment.this).navigate(R.id.action_home_fragment_to_login_fragment));

        mRegisterButton = (Button) v.findViewById(R.id.register_button);
        mRegisterButton.setOnClickListener(view -> NavHostFragment.findNavController(home_fragment.this).navigate(R.id.action_home_fragment_to_register_fragment));

        return v;
    }
}