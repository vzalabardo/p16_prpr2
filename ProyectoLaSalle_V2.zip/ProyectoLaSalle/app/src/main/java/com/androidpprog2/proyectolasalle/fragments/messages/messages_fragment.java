package com.androidpprog2.proyectolasalle.fragments.messages;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.users.User_adapter;
import com.androidpprog2.proyectolasalle.fragments.events.main_logged_fragment;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.google.gson.Gson;

import java.util.List;


public class messages_fragment extends Fragment implements Message_helper.message_conversations_listener, User_helper.user_listener{
    RecyclerView users_rec_views;
    RecyclerView.Adapter adapter;
    private Context context;

    public messages_fragment() {
        // Required empty public constructor
    }

    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_messages, container, false);
        users_rec_views = v.findViewById(R.id.users_recycler_view);
        users_rec_views.setLayoutManager(new LinearLayoutManager(getContext()));

        Message_helper.get_conversations(messages_fragment.this,context);


        return v;
    }


    @Override
    public void on_message_conversations_receive(List<User> u_list) {

        adapter = new User_adapter(u_list, messages_fragment.this);
        users_rec_views.setAdapter(adapter);

    }

    @Override
    public void on_user_receive(User u) {
        Gson g = new Gson();
        Bundle bundle = new Bundle();
        bundle.putString("user",g.toJson(u));
        NavHostFragment.findNavController(messages_fragment.this).navigate(R.id.action_messages_fragment_to_conversation_fragment,bundle);

    }
}