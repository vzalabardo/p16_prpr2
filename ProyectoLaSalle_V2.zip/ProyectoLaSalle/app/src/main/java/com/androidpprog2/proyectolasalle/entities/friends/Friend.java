package com.androidpprog2.proyectolasalle.entities.friends;

public class Friend {
    String friend = "";
}
