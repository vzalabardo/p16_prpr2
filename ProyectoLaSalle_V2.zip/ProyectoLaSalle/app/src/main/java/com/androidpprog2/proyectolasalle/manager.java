package com.androidpprog2.proyectolasalle;

import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.entities.events.Event;

import java.util.ArrayList;
import java.util.List;

public class manager {
    private static manager manager_instance = null;
    public String url_api = "http://puigmal.salle.url.edu/api/v2/";

    public User user = new User();

    public List<Event> e_list = new ArrayList<Event>();
    public List<User> u_list = new ArrayList<User>();
    public List<User> u_event_list = new ArrayList<User>();

    public static manager get_manager(){
        if(manager_instance == null){
            manager_instance = new manager();
        }
        return manager_instance; }



}
