package com.androidpprog2.proyectolasalle.entities.messages;

import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.androidpprog2.proyectolasalle.R;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.helpers.Event_helper;
import com.androidpprog2.proyectolasalle.helpers.Message_helper;
import com.androidpprog2.proyectolasalle.helpers.User_helper;
import com.androidpprog2.proyectolasalle.manager;
import com.squareup.picasso.Picasso;

public class MessageHolder extends RecyclerView.ViewHolder implements User_helper.user_listener {
   public Message_helper.message_receive_listener onListItemClick;
   public Message message = new Message();
   public TextView user_name;
   public TextView message_content;
   public LinearLayout linearLayout;

    public MessageHolder(View v) {
        super(v);

        user_name = itemView.findViewById(R.id.message_user);
        message_content = itemView.findViewById(R.id.message_content);
        linearLayout = itemView.findViewById(R.id.linear_l);
    }

    public void fill_holder_fields(Message m){
        message = m;
        User_helper.get_user_by_id(MessageHolder.this, itemView.getContext(), String.valueOf(message.user_id_send));
        message_content.setText(message.content);

        if(message.user_id_send == manager.get_manager().user.id){
            linearLayout.setBackgroundColor(Color.parseColor("#5AB33A"));
        }

    }

    @Override
    public void on_user_receive(User u) {
        user_name.setText(u.name + " " + u.last_name);
    }
}
