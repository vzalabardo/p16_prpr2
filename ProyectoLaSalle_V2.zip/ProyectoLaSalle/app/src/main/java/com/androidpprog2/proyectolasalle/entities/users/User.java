package com.androidpprog2.proyectolasalle.entities.users;

import com.androidpprog2.proyectolasalle.entities.Statistic;

public class User {
    public int id = 0;
    public String accesToken = "";
    public String name = "";
    public String last_name="";
    public  String email="";
    public String password;
    public String image="";
    public Statistic statistics= new Statistic();

}
