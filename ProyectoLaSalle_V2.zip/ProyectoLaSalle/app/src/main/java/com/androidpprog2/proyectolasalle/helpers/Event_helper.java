package com.androidpprog2.proyectolasalle.helpers;

import android.content.Context;
import android.util.Log;
import android.view.View;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.androidpprog2.proyectolasalle.entities.events.Event;
import com.androidpprog2.proyectolasalle.entities.users.User;
import com.androidpprog2.proyectolasalle.manager;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Event_helper {
    public interface event_listener{
        void on_event_receive(Event e);}

    public interface events_listener{
        void on_events_receive(List<Event> e_list);
    }
    public interface event_assistances_listener{
        void on_event_assistances_receive(List<User> u_list);
    }
    public interface event_assistance_listener{
        void on_event_assistances_post(View v);
    }
    public interface event_cancel_assistance_listener{
        void on_event_cancel_assistances_post(View v);
    }

    //POST EVENT
    static public void post_event(Event e, Event_helper.event_listener e_listener, Context context){
        String url = manager.get_manager().url_api + "events";
        RequestQueue queue = Volley.newRequestQueue(context);

        JSONObject JSON_user = new JSONObject();
        try {
            JSON_user.put("name",e.name);
            JSON_user.put("image",e.image);
            JSON_user.put("location",e.location);
            JSON_user.put("description",e.description);
            JSON_user.put("eventStart_date",e.eventStart_date);
            JSON_user.put("eventEnd_date",e.eventEnd_date);
            JSON_user.put("n_participators",e.n_participators);
            JSON_user.put("type",e.type);
            }
        catch (JSONException exc) {
            exc.printStackTrace();}

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(
                Request.Method.POST,url, JSON_user,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("respuesta", "Post Evento correcto: "+ response.toString());
                        Gson g = new Gson();
                        Event event = g.fromJson(response.toString(), Event.class);
                        e_listener.on_event_receive(event);

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("respuesta", "Registro de usuario error:" + error);
                Event event = null;
                e_listener.on_event_receive(event);
            }
        }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjReq);
    }

    static public void get_events(events_listener events_listener, Context context){
        String url = manager.get_manager().url_api + "events";
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA EVENTOS: "+ response.toString());

                        Gson g = new Gson();
                        List<Event> e_list = Arrays.asList(g.fromJson(response.toString(), (Type) Event[].class));
                        events_listener.on_events_receive(e_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA ERROR EVENTOS:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    static public void get_event_assistances(event_assistances_listener event_assistances_listener, Context context, String id){
        String url = manager.get_manager().url_api + "events/" + id + "/assistances" ;
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "RESPUESTA EVENT ASSISTANCES: "+ response.toString());

                        Gson g = new Gson();
                        List<User> u_list = Arrays.asList(g.fromJson(response.toString(), (Type) User[].class));
                        event_assistances_listener.on_event_assistances_receive(u_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "RESPUESTA ERROR EVENTOS:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    static public void post_assistance(event_assistance_listener event_assistance_listener, Context context,View v, String id){
        String url = manager.get_manager().url_api + "events/" + id + "/assistances" ;

        RequestQueue queue = Volley.newRequestQueue(context);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "ASSISTANCE POST CORRECT: "+ response.toString());
                        event_assistance_listener.on_event_assistances_post(v);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "ASSISTANCE POST ERROR:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

    static public void get_events_by_value(Event_helper.events_listener events_listener,Context context,String type, String value){
        String url = manager.get_manager().url_api + "events/search" + "?keyword=" + value;
        RequestQueue queue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.e("resposta", "La resposta es: "+ response.toString());
                        JSONObject responseJsonObject = null;
                        try {
                            responseJsonObject = response.getJSONObject(0);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Gson g = new Gson();
                        List<Event> e_list = Arrays.asList(g.fromJson(response.toString(), (Type) Event[].class));
                        events_listener.on_events_receive(e_list);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Hi ha hagut un error:" + error);
                    }
                }){
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token);
                return headers;
            }};
        queue.add(jsonArrayRequest);
    }

    static public void cancel_assistance(event_cancel_assistance_listener event_cancel_assistance_listener, Context context, View v, String id){
        String url = manager.get_manager().url_api + "events/" + id + "/assistances";

        RequestQueue queue = Volley.newRequestQueue(context);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.DELETE, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("resposta", "Cancel event Correct: "+ response.toString());
                        event_cancel_assistance_listener.on_event_cancel_assistances_post(v);
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("resposta", "Cancel event Error:" + error);
                    }
                }){

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                String token = manager.get_manager().user.accesToken;
                headers.put("Authorization", "Bearer " + token.toString());
                return headers;
            }};
        queue.add(jsonObjectRequest);
    }

}
