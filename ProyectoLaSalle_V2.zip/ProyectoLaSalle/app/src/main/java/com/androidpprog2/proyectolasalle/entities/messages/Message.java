package com.androidpprog2.proyectolasalle.entities.messages;

public class Message {
    public int id;
    public String content;
    public int user_id_send;
    public int user_id_recived;
    public String timeStamp;

}
